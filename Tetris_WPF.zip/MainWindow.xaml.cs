﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tetris_WPF
{
   
    public partial class MainWindow : Window
    {
        private readonly ImageSource[] tileImages = new ImageSource[]
        {
            new BitmapImage(new Uri("Assets/пустаяклетка.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/blues_cell.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/blue_cell.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/orange_cell.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/yellow_cell.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/green_cell.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/purple_cell.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/rad_cell.png", UriKind.Relative))
        };

        private readonly ImageSource[] blockImages = new ImageSource[]
       {
            new BitmapImage(new Uri("Assets/клетка.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/I_Block.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Г_Block.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/L_Block.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/O_Block.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/S_Block.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/T_Block.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Z_Block.png", UriKind.Relative))
       };

        private readonly Image[,] imagesControls;
        private readonly int maxDelay = 1000;
        private readonly int minDelay = 75;
        private readonly int delayDecrease = 25;

        private double lastTimestamp = (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) / 1000;
        private double timer = 0.0;
        private GameState gameState;
         
        public MainWindow()
        {
            InitializeComponent();
            gameState = new GameState((block) => {
                DrawBlock(block, gameState.BlockDropDistance(), 1.0);
            });
            imagesControls = SetupGameCanvas(gameState.GameGrid);
        }

        private Image[,] SetupGameCanvas(GameGrid grid)
        {
            Image[,] imageControls = new Image[grid.Rows, grid.Columns];
            int cellSize = 25;

            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    Image imageControl = new Image
                    {
                        Width = cellSize,
                        Height = cellSize,
                    };
                    
                    Canvas.SetTop(imageControl, (r - 2) * cellSize + 10);
                    Canvas.SetLeft(imageControl, c * cellSize);
                    GemeCanvas.Children.Add(imageControl);
                    imageControls[r, c] = imageControl;
                }
            }

            return imageControls;
        }

        private void DrawGrid(GameGrid grid)
        {
            for (int r = 0;r < grid.Rows; r++)
            {
                for (int c = 0;c < grid.Columns; c++)
                {
                    int id = grid[r, c];
                    imagesControls[r, c].Source = tileImages[id];
                }
            }
        }

        private void DrawBlock(Block block, int rowOffset, double opacity = 1.0)
        {
            foreach (Position p in block.TilePositions())
            {
                imagesControls[p.Row + rowOffset, p.Column].Opacity = opacity;
                imagesControls[p.Row + rowOffset, p.Column].Source = tileImages[block.Id];
            }
        }

        private void DrawNextBlock(BlockQueue blockQueue)
        {
            Block next = blockQueue.NextBlock;
            NextImage.Source = blockImages[next.Id];
        }

        private void DrawHeldBlock(Block heldBlock)
        {
            if (heldBlock == null)
            {
                HoldImage.Source = blockImages[0];
            }
            else
            {
                HoldImage.Source = blockImages[heldBlock.Id];
            }
        }

        private void Draw(GameState gameState)
        {
            DrawGrid(gameState.GameGrid);
            DrawBlock(gameState.CurrentBlock, 0);
            DrawNextBlock(gameState.BlockQueue);
            DrawHeldBlock(gameState.HeldBlock);
            ScoreText.Text = $"Score{gameState.Score}";
        }

        private void GameLoop(object? sender, EventArgs e)
        {
            timer += ((DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) / 1000) - lastTimestamp;
            Draw(gameState);

            if (timer >= Math.Max(minDelay, maxDelay - (gameState.Score * delayDecrease)) / 1000)
            {
                gameState.MoveBlockDown();
                timer = 0.0;
            }

            if (gameState.GameOver)
            {
                GameOverMenu.Visibility = Visibility.Visible;
                FinalScoreText.Text = $"Score{gameState.Score}";
            }

            lastTimestamp = (DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond) / 1000;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (gameState.GameOver)
            {
                return;
            }

            switch (e.Key)
            {
                case Key.Left:
                    gameState.MoveBlockLeft(); 
                    break;
                case Key.Right:
                    gameState.MoveBlockRight();
                    break;
                case Key.Down:
                    gameState.MoveBlockDown();
                    break;
                case Key.C:
                    gameState.RotateBlockCW();
                    break;
                case Key.Z:
                    gameState.RotateBlockCCW();
                    break;
                case Key.X:
                    gameState.HoldBlock();
                    break;
                case Key.Space:
                    gameState.DropBlock();
                    break;
                case Key.Escape:
                    Close();
                    break;
                default: 
                    return;
            }
        }

        private void GameCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            CompositionTarget.Rendering += GameLoop;
        }

        private void PlayAgain_Click(object sender, RoutedEventArgs e)
        {
            gameState = new GameState((block) =>
            {
                DrawBlock(block, gameState.BlockDropDistance(), 1.0);
            });
            GameOverMenu.Visibility = Visibility.Hidden;
        }
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
